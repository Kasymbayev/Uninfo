<?php $__env->startSection('content'); ?>

    <div class="container">
        <?php if(isset($details)): ?>
        <div class="row">
            <div class="col-md-12" style="margin-left: 15px;">
                <h3>
                    <?php if(count($search) <= 1): ?>
                    Найдена <?php echo e(count($search)); ?> специальность по вашему запросу "<?php echo e($query); ?>"
                    <?php elseif(count($search) > 1): ?>
                    Найдены <?php echo e(count($search)); ?> специальности по вашему запросу "<?php echo e($query); ?>"
                    <?php endif; ?>
                </h3>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="specialty_blocks">
                        <div class="specialty_inf">
                            <h3><?php echo e($search->specialty_name); ?> - <?php echo e($search->specialty_cipher); ?></h3>
                            <p>Направление: <span><?php echo e($search->direction->direction); ?></span></p>
                            <p>Ученая степень: <span><?php echo e($search->qualification->qualification); ?></span></p>
                            <p>Профильные предметы: <span><?php echo e($search->subject->subject); ?></span></p>
                        </div>
                        <span class="watermark">UniSpecialty</span>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php else: ?>

            <div class="row">
                <div class="col-md-12" style="margin-left: 15px;">
                    <h3>По вашему запросу ничего не найдено</h3>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/pages/search.blade.php ENDPATH**/ ?>