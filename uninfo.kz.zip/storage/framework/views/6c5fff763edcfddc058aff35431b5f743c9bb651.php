<?php $__env->startSection('title','Админ | Основные'); ?>
<?php $__env->startSection('content'); ?>

    <main class="main">
        <div class="container-fluid">

            <div class="section_1">
                <div class="title">
                    <h4>База университетов</h4>
                </div>

                <table class="table table-hover" style="background: white">
                    <thead class="bg-white">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Название</th>
                        <th scope="col">Адрес</th>
                        <th scope="col">Телефон</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Категория</th>
                        <th scope="col">Код</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($university->id); ?></th>
                            <td width="350">
                                <?php echo e($university->title); ?>

                            </td>
                            <td>
                                <?php echo e($university->address); ?>

                            </td>
                            <td><?php echo e($university->phone_number); ?></td>
                            <td><?php echo e($university->email); ?></td>
                            <td><?php echo e($university->university_category); ?></td>
                            <td><?php echo e($university->university_code); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="section_2">
                <div class="title">
                    <h4>Лучшие специальности</h4>
                </div>

                <table class="table bg-primary" style="background: white">
                    <thead class="bg-info">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Шифр</th>
                        <th scope="col">Специальность</th>
                        <th scope="col">Университеты</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialty): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($specialty -> id); ?></th>
                            <td>
                                <?php echo e($specialty-> specialty_cipher); ?>

                            </td>
                            <td>
                                <?php echo e($specialty-> specialty_name); ?>

                            </td>

                            <td><?php echo e($specialty-> university-> title); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <div class="section_2">
                <div class="title">
                    <h4>Категории университетов</h4>
                </div>

                <table class="table bg-white table-hover" style="background: white">
                    <thead class="bg-white">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Категория</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($category->id); ?></th>
                            <td>
                                <?php echo e($category->category_name); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

        </div>
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/admin/index.blade.php ENDPATH**/ ?>