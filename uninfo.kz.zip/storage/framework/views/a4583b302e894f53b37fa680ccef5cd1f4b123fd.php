<?php $__env->startSection('content'); ?>

    <div class="content">
        <div class="container" style="margin-top: 30px">
            <div class="row">
                <div id="MyAccountsTab" class="tabbable tabs-left">
                    <ul  class="nav nav-tabs col-md-2 col-xs-12">
                        <div class="mycab">
                            <div class="cabtitle">
                                <span class="account-type">Здравствуйте, <?php echo e(\Illuminate\Support\Facades\Auth::user()->firstname); ?></span>
                            </div>
                        </div>
                        <li class="active">
                            <div data-target="#lA" data-toggle="tab" class="nava">
                                <div>
                                    <span class="account-type">Избранное</span><br/>
                                </div>
                            </div>
                        </li>

                        <li>
                            <div data-target="#lB" data-toggle="tab" class="nava">
                                <div>
                                    <span class="account-type">Сравнения</span><br/>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div data-target="#lC" data-toggle="tab" class="nava">
                                <div>
                                    <span class="account-type">Поданные документы</span><br/>
                                </div>
                            </div>
                        </li>
                    </ul>
                    <div class="tab-content col-md-10">
                        <div class="tab-pane active" id="lA">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3 style="margin-top: -30px;">Избранное</h3>
                                    <br>
                                    <?php if(!$favorites->isEmpty()): ?>
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Названия ВУЗА</th>
                                            <th>Действие</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                                <?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><a href="#"><?php echo e($favorite->university->title); ?></a></td>
                                                    <td><a href="#">Удалить</a></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                    <?php else: ?>
                                        <div class="no_compare">
                                            <h3>
                                                Упс!<br>
                                                <span>
                                                    Нет избранных,<br>
                                                        <a href="<?php echo e(route('index')); ?>">Добавить</a>
                                                </span>
                                            </h3>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane" id="lB">
                            <h3 style="margin-top: -30px;">Сравнения</h3>
                            <div class="uni_inform">
                                Чтобы открыть страницу университета, нажмите на его изображение
                            </div>
                                    <div class="compare_style">
                                        <?php if(!$compare->isEmpty()): ?>
                                            <div class="compare_cards">
                                                <?php $__currentLoopData = $compare; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compare): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="<?php echo e(route('uni.show',
                                                        [

                                                        'id'   => $compare->university->id,
                                                        'slug' => str_slug($compare->university->title)
                                                        ]
                                                    )); ?>">
                                                    <div class="col-md-3 compare_card">
                                                        <div class="uni_picture_compare">
                                                            <img src="<?php echo e(asset('public/images/university_img/'.$compare->university->university_img)); ?>">
                                                        </div>
                                                        <div class="compare_title">
                                                            <h5><?php echo e($compare->university->title); ?></h5>
                                                            <div class="delete_btn">
                                                                <a href="#">Убрать</a>
                                                            </div>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Аббревиатура: <span class="answer"><small><?php echo e($compare->university->abbreviation); ?></small></span> </p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Ректор: <span class="answer"><small><?php echo e($compare->university->rector); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Военная кафедра: <span class="answer"><small><?php echo e($compare->university->military_dep); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Средний балл поступления: <span class="answer"><small><?php echo e($compare->university->average_grade); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Средняя стоимость обучения: <span class="answer"><small><?php echo e($compare->university->average_price); ?></small> тг/в год</span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Код университета: <span class="answer"><small><?php echo e($compare->university->university_code); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Адрес: <span class="answer"><small><?php echo e($compare->university->address); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Приемная коммисия: <span class="answer"><small><?php echo e($compare->university->phone_number); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Факс: <span class="answer"><small><?php echo e($compare->university->fax_number); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Почта: <span class="answer"><small><?php echo e($compare->university->email); ?></small></span></p>
                                                        </div>
                                                        <div class="compare_nav">
                                                            <p>Сайт: <span class="answer"><small><?php echo e($compare->university->website); ?></small></span></p>
                                                        </div>
                                                    </div>
                                                    </a>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                            <?php else: ?>
                                            <div class="no_compare">
                                                <h3>
                                                    Упс!<br>
                                                    <span>
                                                        Нет сравнений,<br>
                                                        <a href="<?php echo e(route('index')); ?>">Добавить</a>
                                                    </span>
                                                </h3>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                        </div>
                        <div class="tab-pane" id="lC">
                            <div class="row">
                                <div class="col-md-12">
                                    <h3>Поданные документы</h3>
                                    <br>
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Названия ВУЗА</th>
                                            <th>Статус</th>
                                            <th>Действие</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td><a href="#">Международный IT Университет</a></td>
                                            <td>Принят</td>
                                            <td><a href="#">Отменить</a></td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script
            src="https://code.jquery.com/jquery-2.0.0.min.js"
            integrity="sha256-1IKHGl6UjLSIT6CXLqmKgavKBXtr0/jJlaGMEkh+dhw="
            crossorigin="anonymous"></script>
    <script src="/js/jquery-1.10.2.min.js"></script>
    <script src="js/bootstrap.js"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/account/cabinet.blade.php ENDPATH**/ ?>