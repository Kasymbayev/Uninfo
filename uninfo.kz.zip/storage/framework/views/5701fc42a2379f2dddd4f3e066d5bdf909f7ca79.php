<?php $__env->startSection('content'); ?>

    <div class="wrapper">
        <div class="header">
            <div class="search_section">
                <div class="main_object">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <h3>Найти Университет мечты</h3>
                                <p>Помощник по поиску вуза поможет подобрать вам университет</p>
                            </div>
                        </div>
                        <div class="row">
                            <form action="<?php echo e(route('search')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <div class="search_section_inputs">
                                    <div class="col-md-6 col-xs-12 inputs border_l">
                                        <input type="text" placeholder="Введите название или шифр специальности" name="subject" required>
                                    </div>
                                    <div class="col-md-6 col-xs-12 inputs border_r">
                                        <input type="submit" value="Вперед">
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <?php if(empty($university)): ?>
                <div class="section_two">
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="section_title">
                                    <h3>Популярные ВУЗЫ страны</h3>
                                    <p>Это то, что смотрят пользователи</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="uni_cards">
                                <?php $__currentLoopData = $universities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $university): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-3 uni_card">
                                        <div class="status_stick_accept">
                                            <div class="status_text">
                                                <p>На проверке</p>
                                            </div>
                                        </div>
                                        <a href="<?php echo e(route('uni.show',

                                [
                                    'id' => $university->id,
                                    'slug' => str_slug($university->title)
                                ]

                                )); ?>">
                                            <div class="uni_picture">
                                                <img src="<?php echo e(asset('public/images/university_img/'.$university->university_img)); ?>">
                                            </div>
                                            <div class="uni_title">
                                                <h5><?php echo e($university->title); ?></h5>
                                            </div>
                                            <div class="average_coin">
                                                <span>Средний балл ЕНТ</span>
                                                <p><?php echo e($university->average_grade); ?></p>
                                            </div>
                                            <div class="price_of_year">
                                                <span>Стоимость обучения в год</span>
                                                <p><?php echo e($university->average_price); ?> тг</p>
                                            </div>
                                        </a>
                                        <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                                            <div class="bottom_card_nav university_buttons">
                                                <form action="<?php echo e(route('add.favorite')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>

                                                    <input type="hidden" name="university_id" value="<?php echo e($university->id); ?>">
                                                    <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                                    <button type="submit"><div class="card_nav_favorit"></div></button>
                                                </form>
                                                <form action="<?php echo e(route('add.compare')); ?>" method="post">
                                                    <?php echo csrf_field(); ?>

                                                    <input type="hidden" name="university_id" value="<?php echo e($university->id); ?>">
                                                    <input type="hidden" name="user_id" value="<?php echo e(\Illuminate\Support\Facades\Auth::user()->id); ?>">
                                                    <button type="submit"><div class="card_nav card_nav_repeat"></div></button>
                                                </form>
                                            </div>
                                        <?php else: ?>
                                            <div class="no_auth">
                                                <a href="<?php echo e(route('login')); ?>"><span>Войдите для просмотра информации</span></a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                Нет популярных
            <?php endif; ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/pages/index.blade.php ENDPATH**/ ?>