<?php $__env->startSection('title','Профильные предметы'); ?>
<?php $__env->startSection('content'); ?>
    <main class="main">
        <div class="container-fluid">

            <div class="section_1">
                <div class="row">
                    <div class="col-md-9">
                        <div class="title">
                            <h4>Профильные предметы</h4>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-12">
                        <div class="action-button">
                            <a href="<?php echo e(route('admin_add_subject')); ?>">Добавить профильный предмет</a>
                        </div>
                    </div>
                </div>

                <table class="table" style="background: white">
                    <thead class="bg-info">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Тип</th>
                        <th scope="col" class="text-right">Действие</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($subject->id); ?></th>
                                <td>
                                    <?php echo e($subject->subject); ?>

                                </td>
                                <td>
                                    <div class="uni_action text-right">
                                        <a href="#" class="action-edit" title="Редактировать"><i class="fas fa-pencil-alt"></i></a>
                                        <a href="#" class="action-delete" title="Удалить"><i class="fas fa-trash-alt"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>


        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/admin/subject.blade.php ENDPATH**/ ?>