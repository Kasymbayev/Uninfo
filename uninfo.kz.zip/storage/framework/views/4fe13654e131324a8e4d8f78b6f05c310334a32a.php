;

<?php $__env->startSection('content'); ?>

    <div class="content">

        <div class="container">
            <div class="row">
                <div class="col-md-12" style="margin-left: 15px;">
                    <h3>Специальности на UNINFO</h3>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <div class="filter">
                        <ul>
                            <li>
                                <a href="<?php echo e(route('bachelor')); ?>">Бакалавриат</a>
                                <a href="<?php echo e(route('magistr')); ?>">Магистратура</a>
                                <a href="#">Докторантура PhD</a>
                                <a href="#">Резидентура</a>
                                <a href="#">По профильным предметам</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-12">
                    <?php $__currentLoopData = $specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $speciality): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="specialty_blocks">
                        <div class="specialty_inf">
                            <h3><?php echo e($speciality->specialty_name); ?> - <?php echo e($speciality->specialty_cipher); ?></h3>
                            <p>Направление: <span><?php echo e($speciality->direction->direction); ?></span></p>
                            <p>Ученая степень: <span><?php echo e($speciality->qualification->qualification); ?></span></p>
                            <p>Профильные предметы: <span><?php echo e($speciality->subject->subject); ?></span></p>
                        </div>
                        <span class="watermark">UniSpecialty</span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/pages/specialty.blade.php ENDPATH**/ ?>