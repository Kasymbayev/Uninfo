<?php if(session()->has('success')): ?>
    <script type="text/javascript">
        $(function(){
            alertify.set('notifier','position', 'top-center');
            alertify.notify(" <?php echo session()->get('success'); ?>", 'success').setHeader('Успех');
            alertify.success("<?php echo session()->get('success'); ?>");
        });
    </script>

<?php elseif(session()->has('error')): ?>
    <script type="text/javascript">
        $(function(){
            alertify.set('notifier','position', 'top-center');
            alertify.notify(" <?php echo session()->get('error'); ?> ", 'error').setHeader('Ошибка');
            alertify.error("<?php echo session()->get('error'); ?>");
        });
    </script>
<?php endif; ?>

<?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/inc/messages.blade.php ENDPATH**/ ?>