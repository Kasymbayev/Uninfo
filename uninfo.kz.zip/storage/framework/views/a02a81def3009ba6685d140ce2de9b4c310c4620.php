<?php $__env->startSection('content'); ?>

    <div class="content" style="background: #fff;">

        <div class="container">
            <div class="university_information">
                <div class="row">
                    <div class="col-md-6 uni_info">
                        <h2><?php echo e($universities->title); ?> <small>(<?php echo e($universities->abbreviation); ?>)</small></h2>
                        <div class="row">
                            <div class="col-md-12 uni_descr">
                            <span>
                                <?php echo e($universities->description); ?>

                            </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 uni_img">
                        <img src="<?php echo e(asset('public/images/university_img/'.$universities->university_img)); ?>" alt="">
                    </div>
                </div>
                <div class="main_inf">
                    <div class="row">
                            <div class="more_inf">
                                <div class="col-md-7">
                                    <h4><strong>Ректор</strong>: <?php echo e($universities->rector); ?></h4>
                                </div>
                                <div class="col-md-5">
                                    <h4><strong>Аббревиатура</strong>: <?php echo e($universities->abbreviation); ?></h4>
                                </div>
                            </div>
                            <div class="more_inf">
                                <div class="col-md-7">
                                    <h4><strong>Категория</strong>: <?php echo e($universities->university_category); ?></h4>
                                </div>
                                <div class="col-md-5">
                                    <h4><strong>Код университета</strong>: <?php echo e($universities->university_code); ?></h4>
                                </div>
                            </div>
                            <div class="more_inf">
                                <div class="col-md-7">
                                    <h4><strong>Адрес</strong>: <?php echo e($universities->address); ?></h4>
                                </div>
                                <div class="col-md-5">
                                    <h4><strong>Военная кафедра</strong>: <?php echo e($universities->military_dep); ?></h4>
                                </div>
                            </div>
                            <div class="more_inf">
                                <div class="col-md-7">
                                    <h4><strong>Телефон</strong>: <?php echo e($universities->phone_number); ?></h4>
                                </div>
                                <div class="col-md-5">
                                    <h4><strong>Факс</strong>: <?php echo e($universities->fax_number); ?></h4>
                                </div>
                            </div>
                            <div class="more_inf">
                                <div class="col-md-7">
                                    <h4><strong>E-mail</strong>: <?php echo e($universities->email); ?></h4>
                                </div>
                                <div class="col-md-5">
                                    <h4><strong>Сайт</strong>: <a href="<?php echo e($universities->website); ?>">Нажми меня</a></h4>
                                </div>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main_index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OSPanel\domains\uninfo.kz\resources\views/pages/show_university.blade.php ENDPATH**/ ?>