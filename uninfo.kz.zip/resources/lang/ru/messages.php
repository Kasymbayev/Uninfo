<?php

return [
    'auth' => [
        'successLogin' => 'Вы успешно вошли!',
        'errorLogin' => 'Не удалось войти!',
    ]
];